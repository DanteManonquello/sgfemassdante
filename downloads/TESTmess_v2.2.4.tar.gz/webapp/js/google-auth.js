/* ================================================================================
   GOOGLE AUTH - VERSIONE 2.2.3 - FIX AUTHENTICATION ERRORS
   
   CHANGELOG 2.2.3:
   - ✅ CRITICO: Setup wizard per configurazione Client ID
   - ✅ Validazione Client ID prima dell'autenticazione
   - ✅ Error handling dettagliato con messaggi specifici
   - ✅ Debug panel per troubleshooting
   - ✅ Istruzioni chiare per configurazione Google OAuth
   
   CHANGELOG 2.1.1:
   - ✅ CRITICO: Esposto accessToken a window per google-calendar.js
   - ✅ Fix: La sincronizzazione calendario ora funziona dopo login
   ================================================================================ */

// ===== CONFIGURAZIONE =====
let GOOGLE_CLIENT_ID = localStorage.getItem('sgmess_google_client_id') || '432043907250-blb72vqc0nqm8rccoknfe29p4j5lbubr.apps.googleusercontent.com';
const REDIRECT_URI = window.location.origin;
const GOOGLE_API_KEY = 'AIzaSyDm2z0X0d6a73Uhe9wZpFLkZqnVY3EAJuQ';
const SCOPES = 'https://www.googleapis.com/auth/contacts https://www.googleapis.com/auth/calendar.readonly';

let tokenClient;
let accessToken = null;
let gapiInited = false;
let gisInited = false;
let userProfileData = null;
let authDebugMode = localStorage.getItem('sgmess_debug_mode') === 'true';

// ===== SETUP WIZARD =====
function showSetupWizard(errorDetails = '') {
    const modal = document.getElementById('setupWizardModal');
    if (!modal) {
        console.error('❌ Setup wizard modal not found in HTML');
        return;
    }
    
    const errorSection = document.getElementById('setupErrorDetails');
    if (errorSection && errorDetails) {
        errorSection.innerHTML = `
            <div style="background: #fee; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <strong>🔍 Dettagli errore:</strong><br>
                <code style="color: #c00; font-size: 12px;">${errorDetails}</code>
            </div>
        `;
    }
    
    // Mostra origin corrente
    const currentOriginSpan = document.getElementById('currentOrigin');
    if (currentOriginSpan) {
        currentOriginSpan.textContent = window.location.origin;
    }
    
    modal.style.display = 'flex';
}

function closeSetupWizard() {
    const modal = document.getElementById('setupWizardModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function saveClientIdFromWizard() {
    const input = document.getElementById('clientIdInput');
    if (!input || !input.value.trim()) {
        alert('⚠️ Inserisci un Client ID valido');
        return;
    }
    
    const newClientId = input.value.trim();
    
    // Validazione formato
    if (!newClientId.endsWith('.apps.googleusercontent.com')) {
        alert('⚠️ Il Client ID deve terminare con .apps.googleusercontent.com');
        return;
    }
    
    // Salva in localStorage
    localStorage.setItem('sgmess_google_client_id', newClientId);
    GOOGLE_CLIENT_ID = newClientId;
    
    closeSetupWizard();
    
    // Mostra notifica e richiedi reload
    if (window.mostraNotifica) {
        mostraNotifica('✅ Client ID salvato! Ricarica la pagina per applicare le modifiche.', 'success');
    }
    
    setTimeout(() => {
        if (confirm('Client ID configurato! Ricaricare la pagina ora?')) {
            location.reload();
        }
    }, 1500);
}

function toggleDebugMode() {
    authDebugMode = !authDebugMode;
    localStorage.setItem('sgmess_debug_mode', authDebugMode.toString());
    
    const debugPanel = document.getElementById('authDebugPanel');
    if (debugPanel) {
        debugPanel.style.display = authDebugMode ? 'block' : 'none';
    }
    
    if (window.mostraNotifica) {
        mostraNotifica(`Debug mode: ${authDebugMode ? 'ON' : 'OFF'}`, 'info');
    }
}

function logDebug(message, data = null) {
    if (!authDebugMode) return;
    
    const debugOutput = document.getElementById('debugOutput');
    if (!debugOutput) return;
    
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = document.createElement('div');
    logEntry.style.marginBottom = '8px';
    logEntry.style.fontSize = '12px';
    logEntry.innerHTML = `<strong>[${timestamp}]</strong> ${message}`;
    
    if (data) {
        logEntry.innerHTML += `<br><code style="color: #666;">${JSON.stringify(data, null, 2)}</code>`;
    }
    
    debugOutput.appendChild(logEntry);
    debugOutput.scrollTop = debugOutput.scrollHeight;
}

// ===== INIT GAPI =====
function gapiLoaded() {
    gapi.load('client', initializeGapiClient);
}

async function initializeGapiClient() {
    try {
        await gapi.client.init({
            apiKey: GOOGLE_API_KEY,
            discoveryDocs: [
                'https://people.googleapis.com/$discovery/rest?version=v1',
                'https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest'
            ],
        });
        gapiInited = true;
        maybeEnableButtons();
        console.log('✅ Google API Client inizializzato');
        logDebug('✅ GAPI inizializzato correttamente');
    } catch (error) {
        console.error('❌ Errore GAPI:', error);
        logDebug('❌ Errore GAPI', error);
        gapiInited = true; // Continua comunque
        maybeEnableButtons();
    }
}

// ===== INIT GIS =====
function gisLoaded() {
    try {
        // Validazione Client ID
        if (!GOOGLE_CLIENT_ID || GOOGLE_CLIENT_ID.trim() === '') {
            console.error('❌ Client ID non configurato');
            logDebug('❌ Client ID vuoto o mancante');
            showSetupWizard('Client ID non configurato. Configura il tuo Client ID Google OAuth.');
            return;
        }
        
        tokenClient = google.accounts.oauth2.initTokenClient({
            client_id: GOOGLE_CLIENT_ID,
            scope: SCOPES,
            callback: handleAuthResponse,
            error_callback: handleAuthError,
        });
        
        gisInited = true;
        maybeEnableButtons();
        console.log('✅ Google Identity Services inizializzato (popup mode)');
        logDebug('✅ GIS inizializzato', { 
            clientId: GOOGLE_CLIENT_ID.substring(0, 20) + '...', 
            origin: window.location.origin 
        });
    } catch (error) {
        console.error('❌ Errore GIS init:', error);
        logDebug('❌ Errore inizializzazione GIS', error);
        showSetupWizard(`Errore inizializzazione: ${error.message}`);
    }
}

function maybeEnableButtons() {
    if (gapiInited && gisInited) {
        const btn = document.getElementById('googleSignInBtn');
        if (btn) {
            btn.disabled = false;
            console.log('✅ Pulsante Google abilitato');
            logDebug('✅ Pulsante login abilitato');
        }
    }
}

// ===== AUTH =====
function handleAuthClick() {
    try {
        console.log('🔐 Richiesta autenticazione...');
        console.log('📍 Current Origin:', window.location.origin);
        console.log('🔑 Client ID:', GOOGLE_CLIENT_ID.substring(0, 30) + '...');
        
        logDebug('🔐 Tentativo autenticazione', {
            origin: window.location.origin,
            clientIdPrefix: GOOGLE_CLIENT_ID.substring(0, 30) + '...'
        });
        
        if (!tokenClient) {
            console.error('❌ Token client non inizializzato');
            logDebug('❌ Token client null');
            mostraNotifica('Errore: servizio Google non inizializzato', 'error');
            showSetupWizard('Token client non inizializzato. Verifica la configurazione del Client ID.');
            return;
        }
        
        // POPUP MODE con select_account
        tokenClient.requestAccessToken({ 
            prompt: 'select_account'
        });
        
        logDebug('📤 Richiesta access token inviata');
        
    } catch (error) {
        console.error('❌ Errore handleAuthClick:', error);
        logDebug('❌ Errore handleAuthClick', error);
        mostraNotifica('Errore durante autenticazione', 'error');
        showSetupWizard(`Errore: ${error.message}`);
    }
}

// ===== ERROR HANDLER =====
function handleAuthError(error) {
    console.error('❌ Errore autenticazione Google:', error);
    logDebug('❌ Errore autenticazione', error);
    
    let errorMessage = 'Errore durante autenticazione';
    let detailedError = '';
    
    // Gestione errori specifici
    if (error.type === 'popup_closed') {
        errorMessage = '🚫 Popup chiuso - autenticazione annullata';
        detailedError = 'L\'utente ha chiuso il popup di autenticazione.';
    } else if (error.type === 'popup_failed_to_open') {
        errorMessage = '❌ Impossibile aprire popup - controlla i popup blocker';
        detailedError = 'Il browser ha bloccato il popup. Abilita i popup per questo sito.';
    } else if (error.type === 'idpiframe_initialization_failed') {
        errorMessage = '❌ Errore inizializzazione Google Identity';
        detailedError = 'Possibile problema: Client ID non autorizzato per questo origin.';
        showSetupWizard(`Origin non autorizzato: ${window.location.origin}<br><br>Aggiungi questo URL alla lista "URI JavaScript autorizzati" nella Google Console.`);
    } else if (error.message) {
        errorMessage = `❌ ${error.message}`;
        detailedError = error.message;
    }
    
    // Se errore generico "Error", mostra setup wizard
    if (error.message === 'Error' || error.toString() === 'Error') {
        errorMessage = '❌ Errore generico - verifica configurazione Client ID';
        detailedError = 'Errore generico di autenticazione. Possibili cause:\n' +
            '1. Client ID non configurato correttamente\n' +
            '2. Origin non autorizzato nella Google Console\n' +
            '3. Redirect URI mancante\n' +
            '4. App non verificata o limitata';
        showSetupWizard(detailedError);
    }
    
    if (window.mostraNotifica) {
        mostraNotifica(errorMessage, 'error');
    }
    
    updateGoogleUIStatus(false);
}

// ===== RESPONSE HANDLER =====
async function handleAuthResponse(resp) {
    if (resp.error !== undefined) {
        console.error('❌ Errore auth:', resp.error, resp);
        logDebug('❌ Errore auth response', resp);
        updateGoogleUIStatus(false);
        
        // Mostra setup wizard con dettagli
        const errorDetails = `Codice: ${resp.error}<br>` +
            `Messaggio: ${resp.error_description || 'N/A'}<br>` +
            `URI: ${resp.error_uri || 'N/A'}`;
        showSetupWizard(errorDetails);
        return;
    }
    
    accessToken = resp.access_token;
    window.accessToken = accessToken;
    console.log('✅ Access token ricevuto');
    logDebug('✅ Access token ricevuto', { tokenLength: accessToken.length });
    
    try {
        const userInfo = await getUserInfo();
        userProfileData = userInfo;
        showUserInfo(userInfo);
        updateGoogleUIStatus(true, userInfo);
        console.log('✅ Autenticato:', userInfo);
        logDebug('✅ Autenticazione completata', userInfo);
        
        // Sincronizza calendario
        if (window.syncCalendarEvents) {
            console.log('🔄 Sincronizzazione calendario automatica...');
            window.syncCalendarEvents(false);
        }
        
        // Imposta data corrente
        if (window.setTodayDate) {
            window.setTodayDate();
        }
    } catch (error) {
        console.error('❌ Errore getUserInfo:', error);
        logDebug('❌ Errore getUserInfo', error);
        updateGoogleUIStatus(false);
    }
}

function handleSignoutClick() {
    if (accessToken) {
        google.accounts.oauth2.revoke(accessToken);
        accessToken = null;
        window.accessToken = null;
    }
    userProfileData = null;
    hideUserInfo();
    updateGoogleUIStatus(false);
    logDebug('🔓 Logout effettuato');
}

// ===== USER INFO =====
async function getUserInfo() {
    try {
        const response = await gapi.client.people.people.get({
            resourceName: 'people/me',
            personFields: 'names,emailAddresses,photos'
        });
        
        return {
            name: response.result.names?.[0]?.givenName || 'Dante',
            email: response.result.emailAddresses?.[0]?.value || '',
            photo: response.result.photos?.[0]?.url || ''
        };
    } catch (error) {
        console.error('❌ Errore getUserInfo:', error);
        return { name: 'Dante', email: '', photo: '' };
    }
}

// ===== SHOW USER INFO =====
function showUserInfo(userInfo) {
    console.log('📸 Mostrando foto profilo:', userInfo.photo);
    
    const signInBtn = document.getElementById('googleSignInBtn');
    if (signInBtn) signInBtn.style.display = 'none';
    
    const userInfoDiv = document.getElementById('userInfo');
    if (userInfoDiv) userInfoDiv.style.display = 'flex';
    
    const profilePic = document.getElementById('userProfilePic');
    if (profilePic && userInfo.photo) {
        profilePic.src = userInfo.photo;
        profilePic.alt = userInfo.name;
        profilePic.title = `Connesso come ${userInfo.name} - Clicca per disconnetterti`;
        profilePic.style.display = 'block';
        console.log('✅ Foto profilo impostata');
    }
    
    const headerAvatar = document.getElementById('headerAvatar');
    if (headerAvatar && userInfo.photo) {
        headerAvatar.innerHTML = `<img src="${userInfo.photo}" alt="${userInfo.name}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;" />`;
    }
    
    if (userInfoDiv) {
        userInfoDiv.onclick = () => {
            if (confirm(`Disconnettere ${userInfo.name}?`)) {
                handleSignoutClick();
            }
        };
    }
    
    const operatoreName = document.getElementById('operatoreName');
    if (operatoreName) {
        operatoreName.textContent = `by ${userInfo.name}`;
    }
    
    localStorage.setItem('sgmess_operator_name', userInfo.name);
    localStorage.setItem('sgmess_operator_photo', userInfo.photo || '');
    
    console.log('✅ User info completo visualizzato');
}

function hideUserInfo() {
    const signInBtn = document.getElementById('googleSignInBtn');
    if (signInBtn) signInBtn.style.display = 'flex';
    
    const userInfoDiv = document.getElementById('userInfo');
    if (userInfoDiv) {
        userInfoDiv.style.display = 'none';
        userInfoDiv.onclick = null;
    }
    
    const headerAvatar = document.getElementById('headerAvatar');
    if (headerAvatar) {
        headerAvatar.innerHTML = '<i class="fas fa-user"></i>';
    }
    
    const operatoreName = document.getElementById('operatoreName');
    if (operatoreName) {
        operatoreName.textContent = 'Stock Gain Messenger';
    }
    
    localStorage.removeItem('sgmess_operator_name');
    localStorage.removeItem('sgmess_operator_photo');
}

function updateGoogleUIStatus(isConnected, userInfo = null) {
    console.log(`Google status: ${isConnected ? 'Online ✅' : 'Offline ❌'}`);
    logDebug(`Status: ${isConnected ? 'ONLINE' : 'OFFLINE'}`);
}

// ===== CHECK CONTATTO ESISTENTE =====
async function checkContactExists(phoneNumber) {
    if (!accessToken) {
        console.warn('⚠️ Non autenticato');
        return false;
    }
    
    try {
        let searchNumber = phoneNumber.replace(/\s+/g, '').replace(/^\+/, '');
        
        const response = await gapi.client.people.people.connections.list({
            'resourceName': 'people/me',
            'personFields': 'names,phoneNumbers',
            'pageSize': 1000
        });
        
        const connections = response.result.connections || [];
        
        for (const person of connections) {
            if (person.phoneNumbers) {
                for (const phone of person.phoneNumbers) {
                    const existingNumber = phone.value.replace(/\s+/g, '').replace(/^\+/, '').replace(/^00/, '');
                    const compareNumber = searchNumber.replace(/^39/, '');
                    
                    if (existingNumber.includes(compareNumber) || compareNumber.includes(existingNumber)) {
                        console.log('ℹ️ Contatto già esistente:', person.names?.[0]?.displayName);
                        return true;
                    }
                }
            }
        }
        
        return false;
        
    } catch (error) {
        console.error('❌ Errore check duplicati:', error);
        return false;
    }
}

// ===== SALVA CONTATTO =====
async function saveContactToGoogle(contactData) {
    if (!accessToken) {
        console.warn('⚠️ Non autenticato');
        return false;
    }
    
    try {
        let phoneNumber = contactData.phone.replace(/\s+/g, '');
        
        const exists = await checkContactExists(phoneNumber);
        if (exists) {
            console.log('ℹ️ Contatto già presente, salvataggio saltato');
            return { skipped: true, reason: 'duplicate' };
        }
        
        if (phoneNumber.startsWith('00')) {
            phoneNumber = '+' + phoneNumber.substring(2);
        } else if (!phoneNumber.startsWith('+')) {
            if (phoneNumber.startsWith('3')) {
                phoneNumber = '+39' + phoneNumber;
            }
        }
        
        const person = {
            names: [{
                givenName: contactData.firstName,
                familyName: contactData.lastName || '',
            }],
            phoneNumbers: [{
                value: phoneNumber,
                type: 'mobile'
            }]
        };
        
        if (contactData.company) {
            person.organizations = [{
                name: contactData.company,
                type: 'work'
            }];
        }
        
        const response = await gapi.client.people.people.createContact({
            resource: person
        });
        
        console.log('✅ Contatto salvato:', response.result);
        return { success: true };
        
    } catch (error) {
        console.error('❌ Errore salvataggio:', error);
        if (error.status === 409) {
            console.log('ℹ️ Contatto già esistente');
            return { skipped: true, reason: 'conflict' };
        }
        return { success: false, error: error };
    }
}

// ===== RESTORE SESSION =====
function restoreSession() {
    const savedName = localStorage.getItem('sgmess_operator_name');
    const savedPhoto = localStorage.getItem('sgmess_operator_photo');
    
    if (savedName && savedPhoto) {
        console.log('🔄 Ripristino sessione salvata');
        
        const headerAvatar = document.getElementById('headerAvatar');
        if (headerAvatar && savedPhoto) {
            headerAvatar.innerHTML = `<img src="${savedPhoto}" alt="${savedName}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;" />`;
        }
        
        const operatoreName = document.getElementById('operatoreName');
        if (operatoreName) {
            operatoreName.textContent = `by ${savedName}`;
        }
    }
}

// ===== EVENT LISTENERS =====
document.addEventListener('DOMContentLoaded', function() {
    const signInBtn = document.getElementById('googleSignInBtn');
    if (signInBtn) {
        signInBtn.addEventListener('click', handleAuthClick);
        signInBtn.disabled = true;
    }
    
    updateGoogleUIStatus(false);
    restoreSession();
    
    // Setup wizard buttons
    const closeWizardBtn = document.getElementById('closeSetupWizard');
    if (closeWizardBtn) {
        closeWizardBtn.addEventListener('click', closeSetupWizard);
    }
    
    const saveClientIdBtn = document.getElementById('saveClientIdBtn');
    if (saveClientIdBtn) {
        saveClientIdBtn.addEventListener('click', saveClientIdFromWizard);
    }
    
    const toggleDebugBtn = document.getElementById('toggleDebugBtn');
    if (toggleDebugBtn) {
        toggleDebugBtn.addEventListener('click', toggleDebugMode);
    }
    
    // Mostra debug panel se attivo
    if (authDebugMode) {
        const debugPanel = document.getElementById('authDebugPanel');
        if (debugPanel) {
            debugPanel.style.display = 'block';
        }
    }
});

// ===== ESPORTA =====
window.gapiLoaded = gapiLoaded;
window.gisLoaded = gisLoaded;
window.saveContactToGoogle = saveContactToGoogle;
window.userProfileData = () => userProfileData;
window.showSetupWizard = showSetupWizard;
window.toggleDebugMode = toggleDebugMode;

console.log('✅ Google Auth v2.2.3 caricato - Setup wizard + error handling migliorato');
